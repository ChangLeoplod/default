<?php defined('SYSPATH') or die('No direct script access.');

class Encrypt extends Kohana_Encrypt {}

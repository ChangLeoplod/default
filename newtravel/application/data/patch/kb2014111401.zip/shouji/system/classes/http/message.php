<?php defined('SYSPATH') or die('No direct script access.');

interface HTTP_Message extends Kohana_HTTP_Message {}
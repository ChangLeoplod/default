<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Memcache extends Kohana_Cache_Memcache {}
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>{$seoinfo['seotitle']}-{$webname}</title>
<meta name="keywords" content="{$seoinfo['keyword']}" />
<meta name="description" content="{$seoinfo['description']}" />
 {php echo Common::getScript('jquery-min.js,idangerous.swiper.js'); }
 {php echo Common::getCss('m_base.css,style.css'); }
</head>

<body>
	{template 'public/top'}
  
  <div class="m-main">
  
		<div class="line_search">
    	<input type="text" id="key" name="key" class="s_text" placeholder="搜索线路" />
    	<a href="#" class="s_btn">搜索</a>
    </div>
    {loop $list $v1}
    <div class="line-lei">
    	<h2><a  href="{$cmsurl}lines/list/kindid/{$v1['id']}">{$v1['kindname']}</a></h2>
      {loop $v1['nextlist'] $v2}
      <dl>
      	<dt><a href="{$cmsurl}lines/list/kindid/{$v2['id']}">{$v2['kindname']}</a></dt>
        <dd>
        {loop $v2['nextlist'] $key $v3}
          {if $key%4==0}
          </dd>
          <dd>
          {/if}
        	<a href="{$cmsurl}lines/list/kindid/{$v3['id']}">{$v3['kindname']}</a>
        {/loop}
        </dd>
      </dl>
      {/loop}
    </div>
    {/loop}
    
	</div>
  
  {template 'public/foot'}
</body>
<script type="text/javascript">
  $('.s_btn').click(function(){
    var key = $('#key').val();
    if(key==''){
      key=0;
    }
    key = encodeURIComponent(key);
    var url = '{$cmsurl}lines/list/key/';
    location.href = url+key;
  });
</script>
</html>

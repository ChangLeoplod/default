<?php
$pcode = 'stourwebcms';
$cVersion ='3.0.201409.1101';
$versiontype ='正式版';
$pubdate ='2014-09-11';
?>
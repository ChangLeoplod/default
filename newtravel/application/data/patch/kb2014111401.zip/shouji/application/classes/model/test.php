<?php
class Model_Test extends Model{

    public function get_msg()
    {
         return 'this is Model_test';
    }
}
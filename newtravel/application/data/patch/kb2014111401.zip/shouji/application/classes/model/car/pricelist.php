<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Car_Pricelist extends ORM {

    protected  $_table_name = 'car_pricelist';

}
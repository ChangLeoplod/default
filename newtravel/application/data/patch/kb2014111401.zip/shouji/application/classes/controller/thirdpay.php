<?php defined('SYSPATH') or die('No direct script access.');
/*
 * 第三方支付控制器
 * */
class Controller_Thirdpay extends Stourweb_Controller{

    public function before()
    {
        parent::before();
    }

    /*
     * 快钱支付
     * */
    public function action_bill()
    {
        $kq_target="https://www.99bill.com/mobilegateway/recvMerchantInfoAction.htm";
        $kq_merchantAcctId = Common::getSysConf('value','cfg_bill_account',0)."01";   //*  商家用户编号		(30)
        $kq_key = Common::getSysConf('value','cfg_bill_key',0);
        $kq_inputCharset	= "1";	//   1 ->  UTF-8		2 -> GBK		3 -> GB2312   default: 1	(2)
        $kq_pageUrl	    = $GLOBALS['cfg_basehost']."/thirdpay/bill_return";	//   直接跳转页面	(256)
        $kq_bgUrl	    = $GLOBALS['cfg_basehost']."/thirdpay/bill_return";	//   后台通知页面	(256)
        $kq_version	    = "mobile1.0";	//*	 版本  固定值 v2.0	(10)
        $kq_language		= "1";	//*  默认 1 ， 显示 汉语	(2)
        $kq_signType		= "1";   //*  固定值 1 表示 MD5 加密方式 , 4 表示 PKI 证书签名方式	(2)
        $kq_payerName		= "";	//   英文或者中文字符	(32)
        $kq_payerContactType = "1";  //  支付人联系类型  固定值： 1  代表电子邮件方式 (2)
        $kq_payerContact   = "";	//	 支付人联系方式	(50)
        $kq_orderId		= $_POST['ordersn'];	//*  字母数字或者, _ , - ,  并且字母数字开头 并且在自身交易中式唯一	(50)
        $kq_orderAmount	= $_POST['price']*100;	//*	  字符金额 以 分为单位 比如 10 元， 应写成 1000	(10)
        $kq_orderTime		= date(YmdHis);  //*  交易时间  格式: 20110805110533
        $kq_productName	= $_POST['subject'];	//	  商品名称英文或者中文字符串(256)
        $kq_productNum		= "1";	//	  商品数量	(8)
        $kq_productId		= "";   //    商品代码，可以是 字母,数字,-,_   (20)
        $kq_productDesc	= "sd";	//	  商品描述， 英文或者中文字符串  (400)
        $kq_ext1			= "";   //	  扩展字段， 英文或者中文字符串，支付完成后，按照原样返回给商户。 (128)
        $kq_ext2			= "";
        $kq_payType		= "10";	//*   支付方式 固定值: 00, 10, 11, 12, 13, 14, 15, 16, 17  (2)
        // 00: 其他支付
        // 10: 银行卡支付
        // 11: 电话支付
        // 12: 快钱账户支付
        // 13: 线下支付
        // 14: 企业网银在线支付
        // 15: 信用卡在线支付
        // 17: 预付卡支付
        // *B2B 支付需要单独申请，默认不开通
        $kq_bankId			= "";   // 银行代码 银行代码 要在开通银行时 使用， 默认不开通 (8)
        $kq_redoFlag		= "0";   // 同一订单禁止重复提交标志  固定值 1 、 0
        // 1 表示同一订单只允许提交一次 ； 0 表示在订单没有支付成功状态下 可以重复提交； 默认 0
        $kq_pid			= "";   //  合作伙伴在快钱的用户编号 (30)
        $kq_all_para=self::kq_ck_null($kq_inputCharset,'inputCharset');
        $kq_all_para.=self::kq_ck_null($kq_pageUrl,"pageUrl");
        $kq_all_para.=self::kq_ck_null($kq_bgUrl,'bgUrl');
        $kq_all_para.=self::kq_ck_null($kq_version,'version');
        $kq_all_para.=self::kq_ck_null($kq_language,'language');
        $kq_all_para.=self::kq_ck_null($kq_signType,'signType');
        $kq_all_para.=self::kq_ck_null($kq_merchantAcctId,'merchantAcctId');
        $kq_all_para.=self::kq_ck_null($kq_payerName,'payerName');
        $kq_all_para.=self::kq_ck_null($kq_payerContactType,'payerContactType');
        $kq_all_para.=self::kq_ck_null($kq_payerContact,'payerContact');
        $kq_all_para.=self::kq_ck_null($kq_orderId,'orderId');
        $kq_all_para.=self::kq_ck_null($kq_orderAmount,'orderAmount');
        $kq_all_para.=self::kq_ck_null($kq_orderTime,'orderTime');
        $kq_all_para.=self::kq_ck_null($kq_productName,'productName');
        $kq_all_para.=self::kq_ck_null($kq_productNum,'productNum');
        $kq_all_para.=self::kq_ck_null($kq_productId,'productId');
        $kq_all_para.=self::kq_ck_null($kq_productDesc,'productDesc');
        $kq_all_para.=self::kq_ck_null($kq_ext1,'ext1');
        $kq_all_para.=self::kq_ck_null($kq_ext2,'ext2');
        $kq_all_para.=self::kq_ck_null($kq_payType,'payType');
        $kq_all_para.=self::kq_ck_null($kq_bankId,'bankId');;
        $kq_all_para.=self::kq_ck_null($kq_redoFlag,'redoFlag');
        $kq_all_para.=self::kq_ck_null($kq_pid,'pid');

        $kq_all_para.=self::kq_ck_null($kq_key,'key');
        $kq_all_para=substr($kq_all_para,0,strlen($kq_all_para)-1);
        $signMsg= strtoupper(md5($kq_all_para));
        $str = <<<_FRM_
        <html>
        <body>
<form method="get" name="kqPay" action="{$kq_target}">
	<input type="hidden" name="inputCharset" value="{$kq_inputCharset}">
	<input type="hidden" name="pageUrl" value="{$kq_pageUrl}">
	<input type="hidden" name="bgUrl" value="{$kq_bgUrl}">
	<input type="hidden" name="version" value="{$kq_version}">
	<input type="hidden" name="language" value="{$kq_language}">
	<input type="hidden" name="signType" value="{$kq_signType}">
	<input type="hidden" name="merchantAcctId" value="{$kq_merchantAcctId}">
	<input type="hidden" name="payerName" value="{$kq_payerName}">
	<input type="hidden" name="payerContactType" value="{$kq_payerContactType}">
	<input type="hidden" name="payerContact" value="{$kq_payerContact}">
	<input type="hidden" name="orderId" value="{$kq_orderId}">
	<input type="hidden" name="orderAmount" value="{$kq_orderAmount}">
	<input type="hidden" name="orderTime" value="{$kq_orderTime}">
	<input type="hidden" name="productName" value="{$kq_productName}">
	<input type="hidden" name="productNum" value="{$kq_productNum}">
	<input type="hidden" name="productId" value="{$kq_productId}">
	<input type="hidden" name="productDesc" value="{$kq_productDesc}">
	<input type="hidden" name="ext1" value="{$kq_ext1}">
	<input type="hidden" name="ext2" value="{$kq_ext2}">
	<input type="hidden" name="payType" value="{$kq_payType}">
	<input type="hidden" name="bankId" value="{$kq_bankId}">
	<input type="hidden" name="redoFlag" value="{$kq_redoFlag}">
	<input type="hidden" name="pid" value="{$kq_pid}">
	<input type="hidden" name="signMsg" value="{$signMsg}">

</form>
</body>
<script language="JavaScript">
    document.forms['kqPay'].submit();
</script>
</html>
_FRM_;
        echo $str;


    }

    /*
     * 快钱同步提醒
     * */
     public function action_bill_return()
     {
         $kq_key = Common::getSysConf('value','cfg_bill_key',0);
         $kq_check_all_para ='';
         $kq_check_all_para.=self::kq_ck_null($_GET[merchantAcctId],'merchantAcctId');
         $kq_check_all_para.=self::kq_ck_null($_GET[version],'version');
         $kq_check_all_para.=self::kq_ck_null($_GET[language],'language');
         $kq_check_all_para.=self::kq_ck_null($_GET[signType],'signType');
         $kq_check_all_para.=self::kq_ck_null($_GET[payType],'payType');
         $kq_check_all_para.=self::kq_ck_null($_GET[bankId],'bankId');
         $kq_check_all_para.=self::kq_ck_null($_GET[orderId],'orderId');
         $kq_check_all_para.=self::kq_ck_null($_GET[orderTime],'orderTime');
         $kq_check_all_para.=self::kq_ck_null($_GET[orderAmount],'orderAmount');
         $kq_check_all_para.=self::kq_ck_null($_GET[bindCard],'bindCard');
         $kq_check_all_para.=self::kq_ck_null($_GET[bindMobile],'bindMobile');
         $kq_check_all_para.=self::kq_ck_null($_GET[dealId],'dealId');
         $kq_check_all_para.=self::kq_ck_null($_GET[bankDealId],'bankDealId');
         $kq_check_all_para.=self::kq_ck_null($_GET[dealTime],'dealTime');
         $kq_check_all_para.=self::kq_ck_null($_GET[payAmount],'payAmount');
         $kq_check_all_para.=self::kq_ck_null($_GET[fee],'fee');
         $kq_check_all_para.=self::kq_ck_null($_GET[ext1],'ext1');
         $kq_check_all_para.=self::kq_ck_null($_GET[ext2],'ext2');
         $kq_check_all_para.=self::kq_ck_null($_GET[payResult],'payResult');
         $kq_check_all_para.=self::kq_ck_null($_GET[errCode],'errCode');
         $kq_check_all_para.=self::kq_ck_null($kq_key,"key");

         $kq_check_all_para=substr($kq_check_all_para,0,strlen($kq_check_all_para)-1);

         $merchantSignMsg= md5($kq_check_all_para);
         //获取加密签名串
         $signMsg=trim($_REQUEST['signMsg']);
         $rtnOK = 0;
         $rtnUrl = '';

         if(strtoupper($signMsg)==strtoupper($merchantSignMsg)){

             switch($_REQUEST['payResult']){
                 case '10':
                     //此处做商户逻辑处理

                     if(substr($_REQUEST['orderId'],0,2)=='dz')
                     {
                         $updatesql="update sline_dzorder set status=2 where ordersn='{$_REQUEST['orderId']}'";
                     }
                     else
                     {
                         $updatesql="update sline_member_order set status=2,ispay=1 where ordersn='{$_REQUEST['orderId']}'"; //付款标志置为1,交易成功
                         DB::query(Database::UPDATE,$updatesql)->execute();
                         $sql="select * from sline_member_order where ordersn='{$_REQUEST['orderId']}'";
                         $orderinfo = DB::query(1,$sql)->execute()->as_array();
                         $arr=$orderinfo[0];
                         $msgInfo = Common::getDefineMsgInfo($arr['typeid'],3);
                         $memberInfo = Common::getMemberInfo($arr['memberid']);
                         $nickname = !empty($memberInfo['nickname']) ? $memberInfo['nickname'] : $memberInfo['mobile'];
                         if(isset($msgInfo['isopen'])) //等待客服处理短信
                         {
                             $content = $msgInfo['msg'];
                             $totalprice = $arr['price'] * $arr['dingnum'];
                             $content = str_replace('{#PRODUCTNAME#}',$arr['productname'],$content);
                             $content = str_replace('{#PRICE#}',$arr['PRICE'],$content);
                             $content = str_replace('{#NUMBER#}',$arr['dingnum'],$content);
                             $content = str_replace('{#TOTALPRICE#}',$totalprice,$content);
                             Common::sendMsg($memberInfo['mobile'],$nickname,$content);//发送短信.
                         }

                     }




                     $rtnOK=1;
                     //以下是我们快钱设置的show页面，商户需要自己定义该页面。
                     $rtnUrl=$GLOBALS['cfg_basehost']."/thirdpay/paysuccess";

                     break;
                 default:
                     $rtnOK=1;
                     //以下是我们快钱设置的show页面，商户需要自己定义该页面。
                     //$rtnUrl=$GLOBALS['cfg_basehost']."/kuaiqian/show.php?msg=false";
                     break;

             }

         }
         else
         {
             $rtnOK=1;
             //以下是我们快钱设置的show页面，商户需要自己定义该页面。
             //$rtnUrl=$GLOBALS['cfg_basehost']."/kuaiqian/show.php?msg=error";

         }
         echo "<result>{$rtnOK}</result> <redirecturl>{$rtnUrl}</redirecturl>";

     }

    /*
     * 支付宝支付
     * */
    public function action_alipay()
    {
       $GLOBALS['cfg_alipay_pid'] = Common::getSysConf('value','cfg_alipay_pid',0); //pid
       $GLOBALS['cfg_alipay_key'] = Common::getSysConf('value','cfg_alipay_key',0); //key
       $GLOBALS['cfg_alipay_account'] = Common::getSysConf('value','cfg_alipay_account',0); //帐号
       include(PUBLICPATH.'/thirdpay/alipay/alipay.config.php');
       include(PUBLICPATH.'/thirdpay/alipay/lib/alipay_submit.class.php');
        /**************************调用授权接口alipay.wap.trade.create.direct获取授权码token**************************/

       //返回格式
        $format = "xml";
       //必填，不需要修改

      //返回格式
        $v = "2.0";
      //必填，不需要修改

     //请求号
        $req_id = date('Ymdhis');
     //必填，须保证每次请求都是唯一

     //**req_data详细信息**

    //服务器异步通知页面路径
        $notify_url = $GLOBALS['cfg_basehost']."/thirdpay/alipay_notifyurl";
   //需http://格式的完整路径，不允许加?id=123这类自定义参数

   //页面跳转同步通知页面路径
        $call_back_url = $GLOBALS['cfg_basehost']."/thirdpay/alipay_backurl";
   //需http://格式的完整路径，不允许加?id=123这类自定义参数

   //操作中断返回地址
        $merchant_url = "http://127.0.0.1:8800/WS_WAP_PAYWAP-PHP-UTF-8/xxxx.php";
   //用户付款中途退出返回商户的地址。需http://格式的完整路径，不允许加?id=123这类自定义参数

   //卖家支付宝帐户
        $seller_email = $GLOBALS['cfg_alipay_account'];
   //必填

   //商户订单号
        $out_trade_no = $_POST['ordersn'];
    //商户网站订单系统中唯一订单号，必填

    //订单名称
        $subject = $_POST['subject'];
    //必填

    //付款金额
        $total_fee = $_POST['price'];
    //必填

    //请求业务参数详细
        $req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $out_trade_no . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . $total_fee . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';

//构造要请求的参数数组，无需改动
        $para_token = array(
            "service" => "alipay.wap.trade.create.direct",
            "partner" => trim($alipay_config['partner']),
            "sec_id" => trim($alipay_config['sign_type']),
            "format"	=> $format,
            "v"	=> $v,
            "req_id"	=> $req_id,
            "req_data"	=> $req_data,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );

        //建立请求
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestHttp($para_token);

         //URLDECODE返回的信息
        $html_text = urldecode($html_text);

        //解析远程模拟提交后返回的信息
        $para_html_text = $alipaySubmit->parseResponse($html_text);

        //获取request_token
        $request_token = $para_html_text['request_token'];


        /**************************根据授权码token调用交易接口alipay.wap.auth.authAndExecute**************************/

//业务详细
        $req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';
//必填

//构造要请求的参数数组，无需改动
        $parameter = array(
            "service" => "alipay.wap.auth.authAndExecute",
            "partner" => trim($alipay_config['partner']),
            "sec_id" => trim($alipay_config['sign_type']),
            "format"	=> $format,
            "v"	=> $v,
            "req_id"	=> $req_id,
            "req_data"	=> $req_data,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );

//建立请求
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter, 'get', '确认');
        echo $html_text;

    }

    /*
     * 支付宝同步返回处理
     * */
    public function action_alipay_backurl()
    {
        $GLOBALS['cfg_alipay_pid'] = Common::getSysConf('value','cfg_alipay_pid',0); //pid
        $GLOBALS['cfg_alipay_key'] = Common::getSysConf('value','cfg_alipay_key',0); //key
        $GLOBALS['cfg_alipay_account'] = Common::getSysConf('value','cfg_alipay_account',0); //帐号
        include(PUBLICPATH.'/thirdpay/alipay/alipay.config.php');
        include(PUBLICPATH.'/thirdpay/alipay/lib/alipay_notify.class.php');
        $alipayNotify = new AlipayNotify($alipay_config);
        $verify_result = $alipayNotify->verifyReturn();
        if($verify_result)
        {
           $this->request->redirect('thirdpay/paysuccess');
        }
        else
        {


        }


    }
    /*
     * 支付宝异步返回处理
     * */
    public function action_alipay_notifyurl()
    {

        $GLOBALS['cfg_alipay_pid'] = Common::getSysConf('value','cfg_alipay_pid',0); //pid
        $GLOBALS['cfg_alipay_key'] = Common::getSysConf('value','cfg_alipay_key',0); //key
        $GLOBALS['cfg_alipay_account'] = Common::getSysConf('value','cfg_alipay_account',0); //帐号
        include(PUBLICPATH.'/thirdpay/alipay/alipay.config.php');
        include(PUBLICPATH.'/thirdpay/alipay/lib/alipay_notify.class.php');
        $alipayNotify = new AlipayNotify($alipay_config);
        $verify_result = $alipayNotify->verifyNotify();

        if($verify_result)
        {
            //解析notify_data
            //注意：该功能PHP5环境及以上支持，需开通curl、SSL等PHP配置环境。建议本地调试时使用PHP开发软件
            $doc = new DOMDocument();
            if ($alipay_config['sign_type'] == 'MD5')
            {
                $doc->loadXML($_POST['notify_data']);
            }

           /*  if ($alipay_config['sign_type'] == '0001')
            {
                $doc->loadXML($alipayNotify->decrypt($_POST['notify_data']));
            }*/

            if( ! empty($doc->getElementsByTagName( "notify" )->item(0)->nodeValue) ) {
                //商户订单号
                $ordersn = $doc->getElementsByTagName( "out_trade_no" )->item(0)->nodeValue;
                //支付宝交易号
                $trade_no = $doc->getElementsByTagName( "trade_no" )->item(0)->nodeValue;
                //交易状态
                $trade_status = $doc->getElementsByTagName( "trade_status" )->item(0)->nodeValue;

                if($trade_status == 'TRADE_FINISHED')
                {


                    echo "success";		//请不要修改或删除
                }
                else if ($trade_status == 'TRADE_SUCCESS')
                {
                    $sql="select * from sline_member_order where ordersn='$ordersn'";
                    $arr1=DB::query(1,$sql)->execute()->as_array();
                    $arr = $arr1[0];

                    if(substr($ordersn,0,2)=='dz')
                    {
                        $ordertype = 'dz';
                        $updatesql="update sline_dzorder set status=2 where ordersn='$ordersn'";
                    }
                    else
                    {
                        $ordertype = 'sys';
                        $updatesql="update sline_member_order set ispay=1,status=2 where ordersn='$ordersn'"; //付款标志置为1,交易成功
                    }
                    DB::query(Database::UPDATE,$updatesql)->execute()->as_array();

                    //logResult('更新成功');

                    //$subject='你成功预订'.$arr['productname'].'产品';
                    //$text="尊敬的{$arr['linkman']},你已经成功在{$GLOBALS['cfg_webname']}预订{$arr['productname']},数量{$arr['dingnum']}.";
                    //sendMsg($subject,$text,$arr['handletel'],$ordersn);

                    if($ordertype !='dz')
                    {
                        $msgInfo = Common::getDefineMsgInfo($arr['typeid'],3);
                        $memberinfo = Common::getMemberInfo($arr['memberid']);
                        $nickname = !empty($memberInfo['nickname']) ? $memberInfo['nickname'] : $memberInfo['mobile'];
                        if(isset($msgInfo['isopen'])) //等待客服处理短信
                        {
                            $content = $msgInfo['msg'];
                            $totalprice = $arr['price'] * $arr['dingnum'];
                            $content = str_replace('{#MEMBERNAME#}',$memberinfo['nickname'],$content);
                            $content = str_replace('{#PRODUCTNAME#}',$arr['productname'],$content);
                            $content = str_replace('{#PRICE#}',$arr['price'],$content);
                            $content = str_replace('{#NUMBER#}',$arr['dingnum'],$content);
                            $content = str_replace('{#TOTALPRICE#}',$totalprice,$content);
                            Common::sendMsg($memberInfo['mobile'],$nickname,$content);//发送短信.
                        }
                    }

                    echo "success";		//请不要修改或删除
                }
            }

            //——请根据您的业务逻辑来编写程序（以上代码仅作参考）——

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        }
        else
        {
            //验证失败
            echo "fail";

            //调试用，写文本函数记录程序运行情况是否正常
            //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
        }


    }


   /*
    * 支付成功页面
    * */
    public function action_paysuccess()
    {
        $this->request->redirect('common/success');
    }
    /*
     * 快钱参数处理
     * */
    private function kq_ck_null($kq_va,$kq_na)
    {
        if($kq_va == "")
        {
            $kq_va="";
        }
        else
        {
            return $kq_va=$kq_na.'='.$kq_va.'&';
        }
    }






}

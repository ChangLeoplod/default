<?php
class Model_Page_Config extends ORM {


    

}
<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Line_Pricelist extends ORM {

    protected  $_table_name = 'line_pricelist';

}
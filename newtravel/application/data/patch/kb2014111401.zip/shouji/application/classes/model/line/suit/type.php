<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Line_Suit_Type extends ORM {
    protected  $_table_name = 'line_suit_type';
	


}
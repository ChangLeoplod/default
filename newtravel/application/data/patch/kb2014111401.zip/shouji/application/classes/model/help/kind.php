<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Help_Kind extends ORM {

    protected  $_table_name = 'help_kind';

}
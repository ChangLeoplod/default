<?php
class Model_Page extends ORM {

    protected  $_table_name = 'page';
    

}
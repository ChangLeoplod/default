<?php
class Model_Role extends ORM {
    protected $_primary_key='roleid';
}
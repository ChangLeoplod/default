<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Qq_Kefu extends ORM {






}
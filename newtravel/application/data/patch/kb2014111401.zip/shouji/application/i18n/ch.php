<?php defined('SYSPATH') or die('No direct script access.');

return array(

    'First'=>'首页',
    'Previous'=>'上一页',
    'Next'=>'下一页',
    'Last'=>'末页'
);
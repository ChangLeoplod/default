<?php
return array (
  'watermark' => 
  array (
    'photo_markon' => '0',
    'photo_marktype' => 'text',
    'photo_waterpos' => '9',
    'photo_marktext' => '思途旅游CMS',
    'photo_fontsize' => '16',
    'photo_diaphaneity' => '80',
    'photo_fontcolor' => 'rgb(255,0,0)',
    'photo_markimg' => 'mark.png',
  ),
)?>